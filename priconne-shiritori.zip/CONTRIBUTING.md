# Contributing to priconne-shiritori

Thanks for your interest.

## How Can I Contribute?

### Error Reporting

There may be uncaught errors that I'm unable to find. If you do manage to 
find an error with this code, please write a report to the issue tracker.